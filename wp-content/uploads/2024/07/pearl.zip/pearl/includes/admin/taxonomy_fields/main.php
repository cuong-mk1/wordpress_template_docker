<?php
require_once($pearl_admin_includes_path . '/taxonomy_fields/category-image.php');
require_once($pearl_admin_includes_path . '/taxonomy_fields/category-products.php');