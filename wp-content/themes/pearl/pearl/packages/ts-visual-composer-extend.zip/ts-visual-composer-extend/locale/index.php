<?php
// Prevents directory listing
?>
