# Change Log

## [1.0.0] - 2016-08-29

* Plugin launch.  Everything's new!
