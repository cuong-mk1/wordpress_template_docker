<?php $pearl_cf7 = array();$pearl_cf7[1011] = '<div class="form-group">[textarea your-message placeholder "Message"]</div>
<div class="form-group">[text* name placeholder "Name"]</div>
<div class="form-group">[email*  email placeholder "Email"]</div>

[submit class:btn class:btn_third class:btn_solid "Submit"]';