<?php $pearl_cf7 = array();$pearl_cf7[1977] = '<div class="request_quote">
   <div class="form-group people mtc_b">
         [text* name placeholder "Name"]
   </div>
  <div class="form-group mail mtc_b">
               [email email placeholder "E-mail (Optional)"]
   </div>
  <div class="form-group phone mtc_b">
               [tel phone placeholder "Phone"]
   </div>
   <div class="form-group chat mtc_b">
      [textarea message placeholder "Message"]
   </div>

   [submit "Send Request"]
</div>';$pearl_cf7[1871] = '<div class="request_quote">
<div class="form-group chat mtc_b">
[textarea message placeholder "Message"]
</div>

<div class="row">
      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group people mtc_b">
               [text* name placeholder "Name"]
            </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group mail mtc_b">
               [email email placeholder "E-mail (Optional)"]
            </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="form-group phone mtc_b">
               [tel phone placeholder "Phone"]
            </div>
      </div>
</div>
<div class="text-center">
[submit "Send Request"]
</div>
</div>';