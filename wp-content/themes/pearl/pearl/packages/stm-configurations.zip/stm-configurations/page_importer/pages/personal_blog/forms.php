<?php $pearl_cf7 = array();$pearl_cf7[156] = '[textarea* textarea-441 placeholder "Message*"]
<div class="row">
    <div class="col-md-6 col-sm-6">
        [text* text-176 placeholder "Name*"]
    </div>
    <div class="col-md-6 col-sm-6">
        [email* email-997 placeholder "Email*"]
    </div>
</div>
<div class="text-center">
[submit class:btn_solid class:btn class:btn_third "Submit"]
</div>';