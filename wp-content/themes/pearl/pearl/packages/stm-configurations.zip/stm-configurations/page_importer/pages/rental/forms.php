<?php $pearl_cf7 = array();$pearl_cf7[1055] = '<div class="row stm_mgb_10">
<div class="col-md-6 col-sm-6">[text* your-name placeholder "Name"]</div>
<div class="col-md-6 col-sm-6">[tel* your-tel placeholder "Phone"]</div>
<div class="col-md-12 col-sm-12">[email* your-email placeholder "Email"]</div>
<div class="col-md-12 col-sm-12">[textarea your-message placeholder "Message"]</div>
</div>
<div class="text-center stm_mgb_30">
<button type="submit" class="btn btn_outline btn_secondary btn_gradient"><span><em>Request a Call back</span></em></button>
</div>';$pearl_cf7[653] = '<div class="row">
<div class="col-md-12 col-sm-12">[textarea your-message placeholder "Message"]</div>
</div>
<div class="row stm_mgb_10">
<div class="col-md-4 col-sm-4">[text* your-name placeholder "Name"]</div>
<div class="col-md-4 col-sm-4">[email* your-email placeholder "Email"]</div>
<div class="col-md-4 col-sm-4">[tel* your-tel placeholder "Phone"]</div>
</div>
<div>
<button type="submit" class="btn btn_outline btn_primary btn_gradient"><span><em>Send Message</em></span></button>
</div>';