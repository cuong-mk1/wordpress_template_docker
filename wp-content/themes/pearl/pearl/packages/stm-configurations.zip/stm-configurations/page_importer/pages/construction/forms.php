<?php $pearl_cf7 = array();
$pearl_cf7[1192] = '<div class="row"><div class="col-md-6 col-sm-6">[text* your-name placeholder "Your Name"]</div><div class="col-md-6 col-sm-6">[email* your-email placeholder "Your Email"]</div></div>[textarea your-message placeholder "Your Message"]

[submit "Submit"]';