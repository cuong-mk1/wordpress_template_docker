<?php $pearl_cf7 = array();$pearl_cf7[1062] = '<div class="row">
	<div class="col-sm-6">
		<div class="form-group">[text* your-name placeholder "Your name*"]</div>
		<div class="form-group">[email* your-email placeholder "E-mail address"]</div>
		<div class="form-group">[tel tel-795 placeholder "Phone number"]</div>
	</div>
	<div class="col-sm-6">
		<div class="form-group">[text text-600 placeholder "Subject"]</div>
		<div class="form-group">[textarea your-message x2  placeholder "How we can help?"]</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12 text-center">
		[submit class:btn class:btn_solid class:btn_lg class:btn_primary "Submit"]
	</div>
</div>';